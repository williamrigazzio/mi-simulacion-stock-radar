# Mi Simulación Stock Radar — 23/09/2026

## Lectura simple del día
Para alimentar la IA también se puede mejorar una central existente, no sólo construir otra. Hoy separamos tres cosas que suelen mezclarse: potencia propuesta, deuda que todavía no cerró y contratos cuyo techo no garantiza ventas.

## Tesis central
Google y Georgia Power proponen ampliar capacidad nuclear; Vista fijó el precio de nueva deuda; Lockheed confirmó un contrato de producción. Hay avances documentados, pero permisos, cierre financiero y pedidos efectivos siguen siendo los próximos controles.

## Prioridad por evidencia y valor educativo — no orden de compra
1. **Google/Georgia Power:** primaria empresarial y Bloomberg vía Energy Connects reabiertos. Tesis de electricidad física para AI; unos 96 MW propuestos, sujetos a aprobación.
2. **Vista:** SEC y Ámbito reabiertos. USD 400 millones adicionales de deuda; no son ganancias ni aumento de producción probado.
3. **Lockheed Martin:** anuncio y Defense News reabiertos. Hasta USD 1.200 millones, no facturación garantizada.
4. **Salud:** Merck y Viking aportan evidencia empresarial en el research nocturno. Etiqueta regulatoria y ensayo experimental son estados distintos; falta corroboración independiente completa.

## Dólar y dos vías de inversión
**Referencias públicas, no cotizaciones ejecutables:** MEP AL30 24 h: $1.534,24 (22/09 16:59:36 Argentina); CCL AL30 24 h: $1.603,64 (22/09 16:59:39 Argentina). Comparar fecha y hora antes de operar; no presentar cierre anterior como precio intradiario. BlueLytics: oficial venta $1.534,00, blue venta $1.555,00; actualización 2026-09-23T08:45:57.526281-03:00. [CriptoYa](https://criptoya.com/api/dolar) · [BlueLytics](https://api.bluelytics.com.ar/v2/latest).

**Argentina:** un CEDEAR representa una fracción de un activo extranjero. Su precio incorpora el dólar implícito (CCL), el ratio y fricciones. Verificar puntas, volumen, comisiones y liquidación en IOL/PPI; estar listado no prueba liquidez ni acceso efectivo hoy. GOOGL es proxy local imperfecto de la tesis nuclear, no una participación directa en Georgia Power.

**Internacional/global:** GOOGL/GOOG, SO, VIST y LMT son las vías empresariales del radar; no equivalen a bonos ni a proyectos independientes. Verificar exchange, moneda, broker, impuestos y precio. Buena empresa no significa buena inversión a cualquier precio, buen instrumento local ni buen tamaño dentro de una cartera.

## Señales centrales y watchlist priorizada

### A. Google / Georgia Power — ampliar lo existente
- **Sector / tickers:** nuclear, utilities, infraestructura AI; GOOGL/GOOG y Southern Company (SO). Georgia Power no se presenta como acción independiente.
- **Qué pasó:** comunicado del 21/09: Google apoyará ampliaciones de potencia en la participación de Georgia Power de Vogtle y Hatch, que agregarían aproximadamente 96 MW. Acuerdo y nueva tarifa NU-1 sujetos a Georgia Public Service Commission; Hatch requiere aprobación de ampliación, mientras Vogtle 1–2 tuvo aprobación en el IRP 2025.
- **Por qué importa:** demanda de data centers puede financiar mejoras en turbinas, bombas, motores y refrigeración del parque existente. Google recibiría créditos de atributos libres de emisiones; no se afirma que recibe electricidad física exclusiva de esos reactores.
- **Primaria distribuida por el emisor:** https://www.prnewswire.com/news-releases/georgia-power-agreement-with-google-to-provide-approximately-900-million-in-projected-benefits-for-customers-and-advance-nuclear-energy-in-georgia-302885197.html
- **Corroboración:** Bloomberg vía Energy Connects, 21/09: https://www.energyconnects.com/news/utilities/2026/september/google-to-fund-power-capacity-increases-at-two-georgia-nuclear-plants/ ; POWER: https://www.powermag.com/google-georgia-power-have-deal-to-support-nuclear-power-plant-uprates/
- **Argentina:** GOOGL listado por Comafi, ratio 58:1; SO no confirmado en los listados consultados. GOOGL es proxy local imperfecto, no exposición nuclear pura. **Global:** GOOGL/GOOG y SO como empresas públicas; acceso del broker, valuación y liquidez de ejecución pendientes.
- **Estado: Fortalece tesis / Vigilar aprobación.** Los US$900 millones son beneficios proyectados para clientes durante la vida de las unidades, no ingresos nuevos de Google ni ahorro realizado hoy. Expedientes 44280/56002 identificados en comunicado; documentos regulatorios completos no auditados aquí.

### B. Vista — financiamiento de largo plazo, todavía sin cierre
- **Sector / instrumento:** energía argentina; VIST como acción/ADS y, por separado, ON de Vista Energy Argentina S.A.U.
- **Qué pasó (22/09):** precio fijado para US$400 millones adicionales de senior notes 2038; precio 99,473%, cupón 7,875%, rendimiento a vida promedio 7,950%. Cierre esperado 09/10/2026. Sólo después del cierre, esa serie totalizaría US$900 millones.
- **Por qué importa:** acceso a deuda larga y costo de capital. No prueba aumento de producción, margen o flujo libre. No atribuir uso específico de fondos que este documento no desarrolla.
- **Primaria:** https://www.sec.gov/Archives/edgar/data/1762506/000119312526398099/d158957d6k.htm
- **Secundaria:** https://www.ambito.com/finanzas/vista-emitira-deuda-us400-millones-ley-nueva-york-n6325470 — título usa “emitió”, pero cuerpo y SEC aclaran pricing y cierre futuro. Para Stock Radar prevalece esa distinción.
- **Argentina:** VIST CEDEAR 3:1 confirmado por Comafi. La ON es otro instrumento: código/ISIN, mínimo, prospecto, book y disponibilidad IOL/PPI pendientes. **Global:** VIST NYSE/BMV identificados en SEC; deuda 144A/Reg S tiene restricciones, no acceso minorista universal.
- **Estado: Vigilar.** Mirar cierre, endeudamiento neto, destino de fondos y flujo operativo, no confundir captar deuda con ganar dinero.

### C. Lockheed Martin — contrato real con techo, no venta inmediata
- **Sector / ticker:** defensa física / LMT.
- **Qué pasó (21/09):** contrato IDIQ del Ejército estadounidense de hasta US$1.200 millones para PrSM Increment 2; cubre producción inicial, pedidos futuros y desarrollo. Nuevos ensayos previstos para 2027.
- **Por qué importa:** avance de ensayo a producción y capacidad industrial para municiones; seguimiento por órdenes financiadas, entregas, márgenes y riesgo de ejecución.
- **Primaria:** https://news.lockheedmartin.com/2026-09-21-Lockheed-Martin-Secures-1-2B-Contract-for-Precision-Strike-Missile-Increment-2-After-Second-Maritime-Test
- **Secundaria abierta:** https://www.defensenews.com/industry/2026/09/22/us-army-awards-lockheed-martin-12b-prsm-contract/
- **Argentina:** LMT CEDEAR 20:1 en Comafi; falta book/spread/volumen. **Global:** LMT NYSE; precio de entrada y acceso efectivo no evaluados.
- **Estado: Fortalece tesis industrial.** IDIQ significa cantidad y entregas aún por determinar; no sumar automáticamente todo el techo a ventas o caja. DoD award completo no abierto; el anuncio empresarial y la corroboración sectorial sí.

### D. Merck — WINREVAIR, nueva información regulatoria
- **Sector / ticker:** big pharma / hipertensión arterial pulmonar / MRK.
- **Qué pasó (22/09):** Merck informa aprobación FDA de actualización de etiqueta incorporando eficacia y seguridad del ensayo HYPERION en adultos recientemente diagnosticados. No es aprobación de un fármaco completamente nuevo.
- **Por qué importa:** evidencia para uso más temprano dentro del recorrido terapéutico; potencial comercial condicionado por práctica clínica, cobertura y seguridad.
- **Primaria:** https://www.merck.com/news/u-s-fda-approves-update-to-the-label-for-winrevair-sotatercept-csrk-to-include-data-from-the-phase-3-hyperion-trial-evaluating-adults-recently-diagnosed-with-pulmonary-arterial-hypertensio/
- **Verificación:** comunicado completo abierto, fecha y NYSE:MRK visibles; Comafi confirma instrumento. Pharmacy Times fue descubierto pero acceso directo devolvió 403. **FDA label/approval package y corroboración independiente sustantiva pendientes**: citar “Merck informó”, sin fingir triple chequeo regulatorio completo.
- **Riesgo:** el comunicado incorpora contraindicación por hipersensibilidad grave y monitoreo hematológico. No convertir reducción relativa de un endpoint compuesto en probabilidad de curación o beneficio bursátil garantizado.
- **Argentina:** MRK CEDEAR 5:1 confirmado; **global:** acción MRK NYSE. Spread, precio, reembolso y efecto incremental en ventas no evaluados.
- **Estado: Fortalece tesis / Vigilar implementación clínica y comercial.**

### E. Viking — sostener la pérdida de peso importa tanto como iniciarla
- **Sector / ticker:** biotech metabólica experimental / VKTX.
- **Qué pasó (22/09):** 8-K y EX-99.1 publican resultados topline de mantenimiento de VK2735 tras 21 semanas de dosis semanales y 12 semanas adicionales de mantenimiento.
- **Dato correctamente comparado:** grupos combinados mantuvieron 90% de la pérdida previa con dosis cada dos semanas y 85% con dosis mensuales, frente a 61% con placebo. Los “hasta 97%” y “hasta 90%” del titular son mejores cohortes, no promedio de todos los tratados. Tampoco significan perder 90% del peso corporal.
- **Por qué importa:** adherencia y comodidad pueden diferenciar tratamientos. No demuestra mantenimiento de varios años ni aprobación comercial.
- **Primaria sustantiva:** https://www.sec.gov/Archives/edgar/data/1607678/000119312526397219/vktx-ex99_1.htm
- **Metadata del filing:** https://www.sec.gov/Archives/edgar/data/1607678/000119312526397219/vktx-20260922.htm — mismo emisor, no corroboración clínica independiente. Barron's apareció en discovery; no se usó artículo no abierto como prueba del ensayo ni de la suba bursátil.
- **Argentina:** VKTX no confirmado en Comafi consultado; no decir que no existe en todos los depositarios. **Global:** Nasdaq:VKTX, biotech de alto riesgo; broker, liquidez, capitalización y precio pendientes.
- **Estado: Vigilar; señal técnica fortalecida, no accionable local confirmado.** Cohortes pequeñas y selección de pacientes tras inducción limitan extrapolación; resultados del sponsor, no auditoría independiente.

## 3. Watchlist base — seguimiento

Barrido por ticker en RSS, SEC submissions y fuentes empresariales seleccionadas. “Sin señal nueva fuerte” significa sin nueva evidencia primaria cerrada en esta corrida, no ausencia universal de noticias.

- **NVDA:** Isaac ROS 5.0 publicado el 22/09, primaria https://blogs.nvidia.com/blog/isaac-ros-5-0-agentic-open-source-robotics/ . Refuerza ecosistema physical AI, no revenue nuevo demostrado. Form 4 detectado; cifra de venta de director no calculada ni promovida. DSX Ready del 21/09 sigue como contexto, sin asumir pedidos por calificación.
- **GOOGL/GOOG:** Google/Georgia Power es la señal operativa nueva de energía. Waymo/transit rewards apareció en discovery; monetización incremental no verificada.
- **HOOD:** Form 144 detectado, no prueba venta consumada. RHJ revisado: sin cambio material verificado; detalle interno en sección 9, fuera de brief si no hay novedad.
- **TSLA:** participación BESS en DSX del día anterior; sin nuevo catalyst primario de autonomía cerrado. Optimus y revisiones de analistas quedan fuera.
- **RKLB, PLTR, TSM, MU, AAPL, ASML:** revisados, sin señal nueva fuerte primaria cerrada. TSM tuvo falla transitoria de red y retry exitoso, sin filings desde 21/09. AAPL Form 144 es aviso, no cambio del negocio.
- **AVGO, SNDK, CBRS:** incluidos además de la base. SNDK tiene Forms 4; sin nuevo resultado operativo cerrado. Titulares contradictorios de caídas/récords de chips no se usan como cinta de precios.
- **Memoria AI:** HBM/MU/SKHY versus SSD/SNDK y networking sigue tesis estructural; no apareció evidencia para afirmar “fin de HBM”. Claims de forecast débil SK Hynix requieren primaria y período exacto.
- **Gold / GLD / GOLD / B:** exposición sigue ambigua; sin precio asignado ni inferencia de posición. **RVI:** identidad confirmada como fondo cerrado, no empresa operativa.
- **Cartera real:** Ricardo liquidada/devuelta; no se calculó P&L ni se inventaron posiciones.

## 4. Energéticas — mapa de oportunidad

1. **Generación nuclear existente:** Google/Georgia Power, sección 2. Mejorar plantas puede competir con construir desde cero. Depende de permiso, presupuesto y cronograma.
2. **Nuclear nueva / GEV-Hitachi:** el 22/09 SGE, GE Vernova, Hitachi y Samsung C&T firmaron MoU para oportunidades BWRX-300 en Europa central/oriental y Reino Unido. Es marco de cooperación, no orden firme ni permiso. Primaria: https://www.gevernova.com/news/press-releases/sge-ge-vernova-hitachi-samsung-ct-sign-mou-advance-bwrx-300-fleet-deployment-europe . GEV CEDEAR 180:1 confirmado; Hitachi 6501.T/HTHIY es exposición indirecta de conglomerado, acceso Argentina/OTC pendiente. Samsung C&T no equivale a Samsung Electronics. Estado: **Vigilar**, secundaria sustantiva pendiente.
3. **Grid / transformadores:** revisados Hitachi Energy, Siemens Energy ENR.DE, HD Hyundai Electric 267260.KS, Hyosung Heavy Industries/HICO 298040.KS, Virginia Transformer y Delta Star. Sin nueva primaria de pedidos verificada en este run. Titular de BESS Hitachi/DSX detectado, pero artículo directo no recuperado. No confundir Hyosung TNC/fibras con Heavy Industries. Virginia Transformer/Delta Star siguen privadas según intake base, sin instrumento directo verificado; Corea/OTC no se presume accesible.
4. **Data-center power / cooling:** DSX permanece confirmación del 21/09; LG/SK cooling apareció en discovery sin primaria cerrada. Texas/permisos es riesgo vigente documentado ayer, no reanuncio de hoy. Fuente histórica de control: https://gov.texas.gov/news/post/governor-abbott-directs-tceq-to-halt-data-center-permits . No se atribuye impacto a proyectos individuales sin mapa geográfico.
5. **Argentina:** VIST aporta señal fresca de financiamiento. YPF recompra de ON del filing 21/09 ya cubierta; PAM/PAMP, TGS y CEPU revisados, sin señal nueva fuerte primaria. No confundir Vista Energy con Vista Gold en búsquedas.

## 5. Farmacéuticas/salud — mapa de oportunidad

- **Big pharma / MRK:** actualización WINREVAIR documentada por fabricante; apertura del label FDA pendiente. No confundir información de etiqueta con nueva molécula.
- **Biotech/metabólicas / VKTX:** mantenimiento de peso verificado por SEC; no recomendar por supuesto rally ni comparar ensayos incompatibles.
- **GLP-1 / NVO:** comunicado distribuido en BioSpace del 21/09 informa REIMAGINE 5: CagriSema 1,0/1,0 mg versus tirzepatide 5 mg en diabetes tipo 2; REDEFINE 9 compara contra placebo en obesidad. https://biospace.com/press-releases/novos-cagrisema-delivers-superior-weight-loss-versus-tirzepatide-in-reimagine-5-trial . **Primaria sindicada, corroboración directa Novo/registro pendiente.** No titular “Novo venció a Lilly” en todas las dosis, poblaciones o indicaciones. No es aprobación; quedan eficacia estimand, abandonos y seguridad detallada por auditar. NVO CEDEAR 7:1 confirmado, ADS NYSE; precio/acceso efectivo pendientes.
- **Oncología/enfermedades raras / AZN:** 6-Ks Enhertu/Klygefa del 21/09 siguen visibles en SEC y ya cubiertos ayer; no se volvió a auditar contenido ni se presentan como decisiones nuevas del 22/09. Opinión CHMP no es aprobación final.
- **LLY / manufactura:** inicio de planta Houston ya cubierto, sin sumar capex por segunda vez. Titular de aprobación oral reciclado no se promueve. Disputa de patentes con Nektar apareció en discovery; no hay veredicto primario verificado.
- **AMGN/Roche/Otsuka y M&A:** señales de ensayos observadas en discovery, todavía sin primaria abierta. No rellenar el brief con aprobaciones, adquisiciones o superioridad clínica no confirmadas. Longevidad/Colossal: sin nueva señal invertible fuerte cerrada.

## 6. Radar amplio fuera de watchlist

**LMT, MRK, VKTX, VIST y SO** ofrecen material más concreto que titulares de precios de la watchlist: contratos, etiqueta, ensayo, costo de deuda y electricidad. Ninguno constituye recomendación de compra.

**Recibo de cobertura:**
- Defensa/guerra física: LMT sí aporta primaria + secundaria; GE Aerospace tiene novedades de governance/dividendo y contexto de encendido GEK800 del 21/09. 8-K GE leído, no confundido con contrato nuevo. AVAV IR volvió a timeout; SEC sin filing nuevo en ventana. RTX/NOC/GD/HWM/KTOS/BA e ITA/XAR revisados mediante discovery sectorial: contratos y acuerdos de soporte no promovidos sin documento primario; cobertura no equivale a auditoría exhaustiva de cada empresa.
- Space/RKLB/SpaceX, robots/Waymo, fintech/agentes, bancos/commodities, consumo defensivo y crypto regulado: revisados a nivel discovery. NVIDIA Isaac ROS sí tiene anuncio técnico primario; no otra señal financiera más fuerte cerrada para desplazar las cinco centrales.
- Joven Inversor: yt-dlp recuperó tres videos y el canal correcto. Fechas de publicación no disponibles en ese flat dump y feed oficial devolvió 404: no afirmar frescura 24–72h. Ambos RSS de Ámbito sí se leyeron; Vista pasó a SEC, titulares de riesgo país/reservas quedaron como discovery, sin números públicos no corroborados.
- Intake de Charly: archivos BABA del 23/08 y 18 CEDEARs del 28/08 leídos completos. BABA es histórico y cierre no revalidado; CEDEARs ya cubiertos ayer con 18/18 listados. No repetir como novedad de hoy. GEV y otros instrumentos centrales reconfirmados en planilla actual; book de broker sigue pendiente.

## 7. Private markets / instrumentos empaquetados

**En todos los casos:** acceso Argentina específico no verificado; ningún ticker internacional acredita CEDEAR, elegibilidad por residencia ni liquidez. Precio de mercado puede diferir del valor patrimonial (NAV). No se evaluó conveniencia de entrada.

- **DXYZ:** fondo cerrado NYSE; emisor mantiene NAV US$34,30 al 30/06 y exposición de esa fecha a Anthropic 14,4%, SpaceX 10,6%, OpenAI 2,6%, en parte mediante vehículos intermedios. Además informa inversiones posteriores hasta agosto: no ignorarlas ni combinarlas con NAV de junio como cartera actual calculada. Precio web `$00.00` es placeholder inválido. Falta precio real, NAV comparable, fees totales y acceso. https://www.destiny.xyz/tech100
- **RVI:** Robinhood Ventures Fund I, fondo cerrado NYSE; NAV US$25,02 al 30/06, nuevas asignaciones Crusoe/Whatnot se reportarán trimestre siguiente. Schedule actualizado y pesos actuales no auditados; entrevistas no los prueban. FAQ antigua dice “plans to list” mientras página vigente dice listado: conservar conflicto textual; SEC confirma identidad. Falta prima/descuento, fees y broker. https://robinhood.com/us/en/ventures/rvi
- **ARKVX:** fondo cerrado de intervalo, no ETF con salida intradiaria automática. Holdings actuales no quedaron recuperados; ventanas/cupos de rescate, mínimos, clases/fees y residencia pendientes. https://www.ark-funds.com/funds/arkvx
- **AGIX:** ETF Nasdaq de acciones públicas y privadas. Emisor al 22/09: NAV US$48,40, market price US$48,61, gasto anual 1%; privados 4,04%, Anthropic 1,10%, Apptronik 0,65%, Ayar 0,50%, Nuro 0,34%, Polymarket 0,17%. Son valores del emisor, no broker vivo ni auditoría independiente. La exposición privada no es el total del fondo; falta spread/volumen/acceso local. https://kraneshares.com/agix/
- **XOVR:** página del emisor redirige a artículo conceptual de inversión crossover/SpaceX, no holdings/NAV/fact sheet actual. No usar narrativa pre-IPO como prueba del estado actual de la participada. Producto y composición actual quedan pendientes antes de hablar públicamente de exposición exacta. https://ershares.com/xovr/
- **VCX / FAPMI–Forge:** VCX apareció en titulares de hype, Fundrise devuelve 405 y Forge 403. No cerrados identidad jurídica, tipo de instrumento, listado, holdings, fees, NAV ni acceso. No transformar índice o plataforma privada en acción negociable. https://fundrise.com/venture · https://forgeglobal.com/

Estado: **RADAR EDUCATIVO GLOBAL / no accionable para decisión concreta sin precio, composición y acceso**. RVI/RVII son fondos distintos; RVII fue revisado en SEC, sin novedad primaria en ventana ni holdings auditados.


## Red flags / hype para ignorar
- Los 96 MW nucleares son propuestos; beneficios proyectados no son ahorro ya realizado.
- Vista: precio fijado no es emisión liquidada. Deuda no es ganancia y el CEDEAR no es la obligación negociable.
- LMT: contrato de cantidades y entregas por definir; el techo no es caja garantizada.
- VKTX es experimental. Mantener una proporción de la pérdida previa no equivale a perder ese porcentaje del peso corporal.
- Form 144 no prueba venta consumada. Fondos privados requieren composición, valor patrimonial, prima/descuento, costos y liquidez actualizados.
- Crypto se limita a educación e infraestructura verificable. CDOF permanece BLACK / NO TOCAR.

## Qué mirar después
1. Google/Georgia: resolución regulatoria, cronograma y potencia realmente incorporada.
2. Vista: cierre previsto para 09/10, documentación de la deuda y endeudamiento neto.
3. LMT: pedidos financiados, entregas y márgenes, no sólo techo contractual.
4. Merck: etiqueta FDA. Viking: tamaños de cohortes, seguridad y seguimiento prolongado.
5. Argentina y global: precio, spread, comisiones y habilitación real del instrumento antes de cualquier decisión humana.

## Fuentes, cobertura y límites
Edición 23/09/2026. Research nocturno de las 02:11 Argentina, ventana 21–23/09; las fuentes preservan su fecha. Esta mañana se reabrieron Georgia Power/PRNewswire, Bloomberg vía Energy Connects, SEC/Vista, Ámbito, Lockheed y Defense News, y se refrescaron fuentes de dólar. El resto conserva el alcance y los pendientes explícitos del barrido nocturno; no se presenta como nueva auditoría exhaustiva de cada ticker.

Ambos intakes manuales de agosto fueron leídos: no son novedades de hoy. Las cifras de precio de acciones y P&L no se publican sin verificación. RHJ/AMC fue revisado durante la noche y no aportó cambio material verificado: no se recicla como titular.

## Servicio privado
**Dólar · Acciones · Consulta privada.** Compra/venta de dólares e inversiones: escribime por privado y lo vemos caso por caso, según objetivos, plazo y riesgo. Cotización sujeta a confirmación al operar.

**No es asesoramiento financiero; es research para decisión humana.**
